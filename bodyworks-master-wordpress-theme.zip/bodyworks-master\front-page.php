<?php get_header(); ?>

<main>
      <section class="hero">
        <div class="hero-image"></div>
        <div class="hero-shade"></div>
        <div class="container hero-content">
          <p class="eyebrow light"><span class="eyebrow-line"></span> East London's independent bodyshop</p>
          <h1>Back to<br /><i>beautiful.</i></h1>
          <p class="hero-copy">From a small scuff to a serious collision, we repair your car properly — with clear advice, careful workmanship and no surprises.</p>
          <div class="hero-actions">
            <a class="button button-primary" href="#estimate">Get a free estimate <span>↗</span></a>
            <a class="button button-ghost" href="tel:+447438879345"><span class="phone-icon">⌕</span> 07438 879345</a>
          </div>
          <div class="hero-note"><span class="stars">★★★★★</span> Rated 5/5 by local customers <span class="note-divider"></span> Photo estimates welcome</div>
        </div>
        <div class="hero-scroll">Scroll to explore <span>↓</span></div>
      </section>

      <section class="trust-strip">
        <div class="container trust-grid">
          <div><strong>01</strong><span>Professional<br />body repairs</span></div>
          <div><strong>02</strong><span>Honest, detailed<br />estimates</span></div>
          <div><strong>03</strong><span>Quality paint &<br />colour matching</span></div>
          <div><strong>04</strong><span>Friendly local<br />WhatsApp support</span></div>
        </div>
      </section>

      <section class="intro section-pad" id="about">
        <div class="container intro-grid">
          <div class="intro-heading reveal">
            <p class="eyebrow"><span class="eyebrow-line"></span> The BODYWORKS difference</p>
            <h2>Good work is<br /><i>worth doing right.</i></h2>
          </div>
          <div class="intro-copy reveal">
            <p>When your car has been damaged, you want more than a quick cover-up. You want to know it is safe, the finish will last, and the person repairing it cares about the result.</p>
            <p>That is how we work at BODYWORKS Master Ltd. Our East London team brings experienced hands, professional materials and straightforward communication to every repair — from first assessment to final handover.</p>
            <a class="text-link" href="#process">How we work <span>↗</span></a>
          </div>
        </div>
      </section>

      <section class="services section-pad" id="services">
        <div class="container">
          <div class="section-heading reveal">
            <div><p class="eyebrow"><span class="eyebrow-line"></span> What we do</p><h2>Repair expertise,<br /><i>without the jargon.</i></h2></div>
            <p>Whatever the damage, we’ll explain what needs doing and why. Select a service to start your estimate.</p>
          </div>
          <div class="service-grid">
            <a class="service-card service-card-dark reveal" href="#estimate" data-service="Accident damage repair">
              <span class="service-number">01</span><span class="service-icon">↯</span><h3>Accident<br />damage</h3><p>From panels and bumpers to full collision repair, we restore your vehicle safely and carefully.</p><span class="card-arrow">↗</span>
            </a>
            <a class="service-card reveal" href="#estimate" data-service="Dent and scratch repair">
              <span class="service-number">02</span><span class="service-icon">⌁</span><h3>Dents &<br />scratches</h3><p>Smart repairs that bring doors, wings and bodywork back to a clean, smooth finish.</p><span class="card-arrow">↗</span>
            </a>
            <a class="service-card reveal" href="#estimate" data-service="Paintwork and respray">
              <span class="service-number">03</span><span class="service-icon">◒</span><h3>Paintwork &<br />resprays</h3><p>Precise colour matching and professional paintwork for a finish that blends beautifully.</p><span class="card-arrow">↗</span>
            </a>
            <a class="service-card reveal" href="#estimate" data-service="Bumper and alloy repair">
              <span class="service-number">04</span><span class="service-icon">◉</span><h3>Bumpers &<br />alloys</h3><p>Repair scuffs, cracks and kerb damage before they become bigger, costlier problems.</p><span class="card-arrow">↗</span>
            </a>
          </div>
          <div class="service-foot reveal"><span>Need a part or tyre?</span><a href="https://wa.me/447438879345?text=Hello%20BODYWORKS%20Master%20Ltd%2C%20I%27d%20like%20to%20ask%20about%20a%20car%20part%20or%20tyre." target="_blank" rel="noreferrer">Ask our parts team on WhatsApp <span>↗</span></a></div>
        </div>
      </section>

      <section class="process section-pad" id="process">
        <div class="container">
          <div class="process-top reveal"><p class="eyebrow light"><span class="eyebrow-line"></span> No mystery, no pressure</p><h2>A better way to<br /><i>get back on the road.</i></h2><p>We keep the process simple, transparent and focused on getting your car right.</p></div>
          <div class="process-steps">
            <div class="process-step reveal"><b>01</b><span class="step-icon">◎</span><h3>Tell us what happened</h3><p>Call, message or send a few photos on WhatsApp. We’ll ask the right questions.</p></div>
            <div class="process-step reveal"><b>02</b><span class="step-icon">⌁</span><h3>Get a clear estimate</h3><p>We inspect the damage and give you an honest, itemised view of the work.</p></div>
            <div class="process-step reveal"><b>03</b><span class="step-icon">✦</span><h3>We do the work</h3><p>Our technicians repair, paint and quality-check your vehicle with care.</p></div>
            <div class="process-step reveal"><b>04</b><span class="step-icon">✓</span><h3>Drive away happy</h3><p>We walk you through the finished repair before handing your keys back.</p></div>
          </div>
        </div>
      </section>

      <section class="work section-pad" id="work">
        <div class="container">
          <div class="section-heading reveal"><div><p class="eyebrow"><span class="eyebrow-line"></span> Recent work</p><h2>Small details.<br /><i>Big difference.</i></h2></div><p>Every repair is different. Our standard stays the same: take the time to make it right.</p></div>
          <div class="gallery">
            <figure class="gallery-feature reveal"><img src="<?php echo esc_url( bodyworks_asset( 'assets/images/paint-panel.jpg' ) ); ?>" alt="Technician working on a vehicle body panel" loading="lazy" /><figcaption><span>01 / Paint & panel</span><strong>Clean lines, seamless finish.</strong></figcaption></figure>
            <figure class="gallery-tile reveal"><img src="<?php echo esc_url( bodyworks_asset( 'assets/images/alloy.jpg' ) ); ?>" alt="Vehicle wheel and brake detail" loading="lazy" /><figcaption><span>02 / Alloy repair</span><strong>Ready for the road.</strong></figcaption></figure>
            <figure class="gallery-tile reveal"><img src="<?php echo esc_url( bodyworks_asset( 'assets/images/bodywork.jpg' ) ); ?>" alt="Silver sports car after repair" loading="lazy" /><figcaption><span>03 / Bodywork</span><strong>Back to beautiful.</strong></figcaption></figure>
          </div>
        </div>
      </section>

      <section class="testimonial section-pad">
        <div class="container testimonial-inner reveal"><span class="quote-mark">“</span><blockquote>They made what could have been a stressful repair feel completely straightforward. The finish is excellent and the communication was brilliant from start to finish.</blockquote><div class="testimonial-meta"><span class="stars">★★★★★</span><span>— Local customer, East London</span></div></div>
      </section>

      <section class="estimate section-pad" id="estimate">
        <div class="container estimate-grid">
          <div class="estimate-intro reveal"><p class="eyebrow light"><span class="eyebrow-line"></span> Start your repair</p><h2>Let’s take a look<br /><i>at the damage.</i></h2><p>Tell us a little about your car and we’ll come back to you with next steps. For the fastest response, include photos via WhatsApp.</p><div class="estimate-contact"><a href="tel:+447438879345"><span>Call us</span><strong>07438 879345 ↗</strong></a><a href="https://wa.me/447438879345" target="_blank" rel="noreferrer"><span>WhatsApp us</span><strong>Message the workshop ↗</strong></a></div></div>
          <form class="estimate-form reveal" id="estimate-form">
            <div class="form-heading"><span>01</span><h3>Request a free estimate</h3><small>We usually reply within one working day.</small></div>
            <div class="form-row"><label>Full name<input name="name" type="text" placeholder="Your name" required /></label><label>Phone number<input name="phone" type="tel" placeholder="07..." required /></label></div>
            <div class="form-row"><label>Vehicle registration<input name="registration" type="text" placeholder="e.g. AB12 CDE" /></label><label>Vehicle make & model<input name="vehicle" type="text" placeholder="e.g. BMW 3 Series" /></label></div>
            <label>What do you need help with?<select name="service" id="service-select" required><option value="">Choose a service</option><option>Accident damage repair</option><option>Dent and scratch repair</option><option>Paintwork and respray</option><option>Bumper and alloy repair</option><option>Not sure — I need advice</option></select></label>
            <label>Tell us a little more<textarea name="message" rows="3" placeholder="Where is the damage? You can add photos in WhatsApp after submitting."></textarea></label>
            <button class="button button-primary" type="submit">Send estimate request <span>↗</span></button>
            <p class="form-status" role="status"></p>
          </form>
        </div>
      </section>

      <section class="faq section-pad" id="faq">
        <div class="container faq-grid"><div class="reveal"><p class="eyebrow"><span class="eyebrow-line"></span> Good to know</p><h2>Questions,<br /><i>answered.</i></h2><p class="faq-lede">Can’t find what you need? <a href="mailto:hello@bodyworkmaster.uk">Email the workshop ↗</a></p></div><div class="faq-list reveal">
          <details open><summary>Can I get an estimate from photos?<span>+</span></summary><p>Yes. Send clear photos from a few angles on WhatsApp with your registration and a short description. We can often give you a helpful initial estimate before seeing the vehicle in person.</p></details>
          <details><summary>How long will my repair take?<span>+</span></summary><p>It depends on the damage, parts and paintwork involved. Once we inspect your car, we’ll give you a realistic timescale and keep you updated if anything changes.</p></details>
          <details><summary>Do you repair insurance accident damage?<span>+</span></summary><p>We can help with accident damage assessments and explain your repair options. Contact us as soon as possible and we’ll talk you through the next step.</p></details>
          <details><summary>Where are you based?<span>+</span></summary><p>We’re on Balmoral Road, E7 0NR, London, serving customers across East London and the surrounding areas. Opening hours are Monday to Saturday, 8:00–18:00.</p></details>
        </div></div>
      </section>
    </main>

<?php get_footer(); ?>
